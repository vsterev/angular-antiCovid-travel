import { IVilla } from 'src/app/shared/interfaces/villa';
import { VillaService } from './../villas/villa.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-auth',
  templateUrl: './home-auth.component.html',
  styleUrls: ['./home-auth.component.css']
})
export class HomeAuthComponent implements OnInit {
  villas: IVilla[] = [];
  constructor(private villaService: VillaService) { }
  from = '120';
  to = '';
  search = '';

  ngOnInit(): void {
    const str = { from: this.from, to: this.to, search: this.search };
    console.log(str);
    this.villaService.villaListExtended(str)
      .subscribe((villas) => {
        this.villas = villas;
      }
      )
  }

}
