import { IVilla } from 'src/app/shared/interfaces/villa';
import { VillaService } from './../villas/villa.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-auth',
  templateUrl: './home-auth.component.html',
  styleUrls: ['./home-auth.component.css']
})
export class HomeAuthComponent implements OnInit {
  villas: IVilla[] = [];
  constructor(private villaService: VillaService) { }

  ngOnInit(): void {
    this.villaService.villaListExtended().subscribe(
      villas => this.villas = villas
    )
  }

}
