import { IVilla } from 'src/app/shared/interfaces/villa';
import { VillaService } from './../villas/villa.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-auth',
  templateUrl: './home-auth.component.html',
  styleUrls: ['./home-auth.component.css']
})
export class HomeAuthComponent implements OnInit {
  villas: IVilla[] = [];
  constructor(private villaService: VillaService) { }
  from = '';
  to = '';
  search = '';
  // str: { from: string, to: string, search: string } = { from: this.from, to: this.to, search: this.search };
  // searchVillas(this.str: any ): void {
  //   this.villaService.villaListExtended(this.str)
  //     .subscribe((villas: IVilla[]) => {
  //       this.villas = villas;
  //     }
  // }
  ngOnInit(): void {
    const str = { from: this.from, to: this.to, search: this.search };
    console.log('ngInit1', str);
    this.villaService.villaListExtended(str)
      .subscribe((villas) => {
        this.villas = villas;
      }
      );
  }
  searchHandler(val: any): any {
    console.log('searchHandler', val);
    this.from = val.from;
    this.to = val.to;
    this.search = val.searchl
    const str = { from: this.from, to: this.to, search: this.search };
    console.log(str);
    this.villaService.villaListExtended(str)
      .subscribe((villas) => {
        this.villas = villas;
      }
      );
  }

}
