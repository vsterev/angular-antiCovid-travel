import { IReservation } from 'src/app/shared/interfaces/reservation';
import { ReservationService } from './../reservation.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  constructor(
    private activatredRoute: ActivatedRoute,
    private reservationService: ReservationService
  ) { }
  reservation: IReservation = {};
  ngOnInit(): void {
    const id = this.activatredRoute.snapshot.params.id;

  }

}
