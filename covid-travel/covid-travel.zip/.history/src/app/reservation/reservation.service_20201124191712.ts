import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IReservation } from '../shared/interfaces/reservation';

@Injectable({
  providedIn: 'root'
})
export class ReservationService {

  constructor(private http: HttpClient) { }
  userReservation(): Observable<IReservation[]> {
    this.http.get('reservation/all');
  }
}
