import { DetailComponent } from './detail/detail.component';
import { RouterModule, Routes } from '@angular/router';
import { AuthLoggedGuard } from '../auth-logged.guard';

const routes: Routes = [
  {
    path: 'res',
    children: [
      // {
      //   path: '',
      //   pathMatch: 'full',
      //   redirectTo: '/cause/create'
      // },
      {
        path: 'detail',
        component: DetailComponent
        // canActivate: [AuthLoggedGuard],
        // data: {
        //   isLogged: false
        // }
      },
      {
        // path: 'register',
        // redirectTo: '/register',
        // canActivate: [AuthLoggedGuard],
        // data: {
        //   isLogged: false
        // }

      },
      {
        // path: 'profile',
        // component: ProfileComponent,
        // canActivate: [AuthLoggedGuard],
        // data: {
        //   isLogged: true
        // }
      }
    ]
  }
];
// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class VillaRoutingModule { }
export const ReservationRoutingModule = RouterModule.forChild(routes);
