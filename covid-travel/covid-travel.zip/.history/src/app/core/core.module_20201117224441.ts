import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationComponent } from './navigation/navigation.component';
import { FooterComponent } from './footer/footer.component';
import { NotFoundComponent } from './not-found/not-found.component';



@NgModule({
  declarations: [NavigationComponent, FooterComponent, NotFoundComponent, NavigationComponent],
  imports: [
    CommonModule
  ]
})
export class CoreModule { }
