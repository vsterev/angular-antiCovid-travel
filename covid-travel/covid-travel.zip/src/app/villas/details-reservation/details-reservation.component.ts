import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-reservation',
  templateUrl: './details-reservation.component.html',
  styleUrls: ['./details-reservation.component.css']
})
export class DetailsReservationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
