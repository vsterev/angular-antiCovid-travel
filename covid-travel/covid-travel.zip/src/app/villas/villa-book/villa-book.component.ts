import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-villa-book',
  templateUrl: './villa-book.component.html',
  styleUrls: ['./villa-book.component.css']
})
export class VillaBookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void { }
}
