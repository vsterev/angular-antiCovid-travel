export interface IUser {
  _id: any;
  // userId: string;
  name: string;
  email: string;
}
