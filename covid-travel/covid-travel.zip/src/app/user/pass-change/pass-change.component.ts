import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pass-change',
  templateUrl: './pass-change.component.html',
  styleUrls: ['./pass-change.component.css']
})
export class PassChangeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
