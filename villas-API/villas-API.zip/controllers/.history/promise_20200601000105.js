const fs = require('fs').promises;
const path = require('path');
const url = path.resolve(__dirname, '..', 'config/database.json');

const result = async () => {
  try {
    let arr = [];
    let data = fs.readFile(url); // need to be in an async function
    arr = [...(JSON.parse(data))]; // the contents of file1.js
  } catch (error) {
    console.log('Vasko', error)
  } 

}
result().then(a=>console.log(a)).catch(err => console.log(err));